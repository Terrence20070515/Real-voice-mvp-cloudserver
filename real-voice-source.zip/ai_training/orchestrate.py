#!/usr/bin/env python3
"""
Real-voice AI 训练测试评估系统
=================================
自对弈循环：生成测试用例 → 考生回答 → 考官评分 → 高分沉淀

用法:
  1. 设置环境变量: export DEEPSEEK_API_KEY="sk-..."
  2. 运行: python3 orchestrate.py
  3. 可选参数: python3 orchestrate.py --rounds 10 --cases 20
"""

import json
import os
import sys
import time
import argparse
from datetime import datetime

import requests
from openai import OpenAI

from config import (
    GENERATOR_KEY, JUDGE_KEY, DEEPSEEK_BASE_URL, DEEPSEEK_MODEL,
    BACKEND_URL, TRAINING_FILE, BAD_CASES_FILE, REPORT_FILE,
    DEFAULT_ROUNDS, CASES_PER_ROUND, SCORE_THRESHOLD_GOOD,
    SCORE_THRESHOLD_BAD, MAX_RETRIES,
)
from prompts import (
    GENERATOR_PROMPT, JUDGE_PROMPT, build_menu_summary,
)

# ═══════════════════════════════════════
# 0. 初始化
# ═══════════════════════════════════════

def init():
    """初始化：创建输出目录，加载菜单"""
    os.makedirs(os.path.dirname(BAD_CASES_FILE), exist_ok=True)
    os.makedirs(os.path.dirname(REPORT_FILE), exist_ok=True)

    menu_path = os.path.join(os.path.dirname(__file__), "..", "backend", "menu.json")
    if not os.path.exists(menu_path):
        print(f"❌ 菜单文件未找到: {menu_path}")
        sys.exit(1)
    with open(menu_path, encoding="utf-8") as f:
        menu = json.load(f)

    if not GENERATOR_KEY or not JUDGE_KEY:
        print("❌ 请设置环境变量:")
        print("   export RV_GENERATOR_KEY='sk-...'  # 案例生成器")
        print("   export RV_JUDGE_KEY='sk-...'      # 考官")
        sys.exit(1)

    return menu, build_menu_summary(menu)


# ═══════════════════════════════════════
# 1. 生成模块：让 LLM 生成多样化测试用例
# ═══════════════════════════════════════

def generate_test_cases(menu_summary: str, count: int, existing_ids: set) -> list[dict]:
    """调用 DeepSeek 生成测试用例"""
    client = OpenAI(api_key=GENERATOR_KEY, base_url=DEEPSEEK_BASE_URL)

    prompt = GENERATOR_PROMPT.replace("{count}", str(count))

    print(f"  🎲 正在生成 {count} 条测试用例...", end=" ", flush=True)

    try:
        resp = client.chat.completions.create(
            model=DEEPSEEK_MODEL,
            messages=[
                {"role": "system", "content": "你是一个测试用例生成器。只输出 JSON 数组，不要任何其他文字。"},
                {"role": "user", "content": prompt}
            ],
            temperature=0.8,
            max_tokens=4096,
        )
        raw = resp.choices[0].message.content.strip()
        # 清理可能的 markdown 代码块包裹
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1]
            if raw.endswith("```"):
                raw = raw[:-3]
        cases = json.loads(raw)
        if not isinstance(cases, list):
            raise ValueError("返回不是数组")

        # 去重：用 user_input 内容去重，而非生成的 ID
        new_cases = []
        for c in cases:
            uid = c.get("user_input", "")
            if uid and uid not in existing_ids:
                c["id"] = f"case_{len(existing_ids)+1:04d}"
                existing_ids.add(uid)
                new_cases.append(c)

        print(f"✅ 生成 {len(new_cases)} 条（去重后）")
        return new_cases
    except Exception as e:
        print(f"❌ 生成失败: {e}")
        return []


# ═══════════════════════════════════════
# 2. 测试模块：调用后端 API 让考生回答
# ═══════════════════════════════════════

def run_test_case(case: dict, session_id: str) -> dict:
    """对后端发起对话请求，记录完整结果"""
    user_input = case["user_input"]

    for attempt in range(MAX_RETRIES):
        try:
            resp = requests.post(
                f"{BACKEND_URL}/api/chat",
                json={"session_id": session_id, "message": user_input},
                timeout=60,
            )
            if resp.status_code == 200:
                data = resp.json()
                return {
                    "case_id": case["id"],
                    "user_input": user_input,
                    "ai_reply": data.get("reply", ""),
                    "status": "ok",
                    "scenario": case.get("scenario", ""),
                    "expected_behaviors": case.get("expected_behaviors", []),
                    "context": case.get("context", {}),
                }
            else:
                print(f"    ⚠️ HTTP {resp.status_code}, 重试 {attempt+1}/{MAX_RETRIES}")
        except requests.exceptions.Timeout:
            print(f"    ⚠️ 超时, 重试 {attempt+1}/{MAX_RETRIES}")
        except Exception as e:
            print(f"    ⚠️ 请求异常: {e}, 重试 {attempt+1}/{MAX_RETRIES}")
        time.sleep(2)

    return {
        "case_id": case["id"],
        "user_input": user_input,
        "ai_reply": "",
        "status": "failed",
        "error": "超过最大重试次数",
        "scenario": case.get("scenario", ""),
    }


def run_test_batch(cases: list[dict], session_prefix: str) -> list[dict]:
    """批量测试，每个 case 用独立 session 避免上下文污染"""
    results = []
    for i, case in enumerate(cases):
        sid = f"{session_prefix}_{case['id']}"
        print(f"  🧪 [{i+1}/{len(cases)}] {case['id']}: {case['user_input'][:40]}...", end=" ", flush=True)
        result = run_test_case(case, sid)
        status = "✅" if result["status"] == "ok" else "❌"
        print(f"{status} ({len(result.get('ai_reply',''))} 字)")
        results.append(result)
        time.sleep(0.5)  # 避免后端过载
    return results


# ═══════════════════════════════════════
# 3. 评估模块：考官打分
# ═══════════════════════════════════════

def evaluate_reply(result: dict, menu_summary: str) -> dict:
    """让考官对单条回复打分"""
    client = OpenAI(api_key=JUDGE_KEY, base_url=DEEPSEEK_BASE_URL)

    if result["status"] != "ok" or not result.get("ai_reply"):
        return {
            "case_id": result["case_id"],
            "scores": {"correctness": 0, "completeness": 0, "no_repetition": 0, "tool_usage": 0, "tone": 0},
            "total": 0,
            "verdict": "fail",
            "reason": "后端无响应",
            "issue_flags": ["backend_failure"],
            "suggestion_for_improvement": "检查后端服务是否正常",
        }

    prompt = JUDGE_PROMPT.replace("{menu_summary}", menu_summary)
    prompt = prompt.replace("{user_input}", result["user_input"])
    prompt = prompt.replace("{ai_reply}", result["ai_reply"])
    prompt = prompt.replace("{expected_behaviors}", json.dumps(result.get("expected_behaviors", []), ensure_ascii=False))

    try:
        resp = client.chat.completions.create(
            model=DEEPSEEK_MODEL,
            messages=[
                {"role": "system", "content": "你是一个严格的质检员。只输出 JSON。"},
                {"role": "user", "content": prompt}
            ],
            temperature=0.1,
            max_tokens=1024,
        )
        raw = resp.choices[0].message.content.strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1]
            if raw.endswith("```"):
                raw = raw[:-3]
        evaluation = json.loads(raw)
        evaluation["case_id"] = result["case_id"]
        return evaluation
    except Exception as e:
        return {
            "case_id": result["case_id"],
            "scores": {},
            "total": 0,
            "verdict": "error",
            "reason": f"评分失败: {e}",
            "issue_flags": [],
        }


def evaluate_batch(results: list[dict], menu_summary: str) -> list[dict]:
    """批量评分"""
    evaluations = []
    for i, r in enumerate(results):
        print(f"  📊 [{i+1}/{len(results)}] 评分 {r['case_id']}...", end=" ", flush=True)
        ev = evaluate_reply(r, menu_summary)
        score = ev.get("total", 0)
        verdict = ev.get("verdict", "error")
        emoji = {"good": "🌟", "pass": "👍", "fail": "👎", "error": "💀"}.get(verdict, "❓")
        print(f"{emoji} {verdict} ({score:.1f}/5)")
        ev["user_input"] = r.get("user_input", "")
        ev["ai_reply"] = r.get("ai_reply", "")
        ev["scenario"] = r.get("scenario", "")
        ev["expected_behaviors"] = r.get("expected_behaviors", [])
        evaluations.append(ev)
    return evaluations


# ═══════════════════════════════════════
# 4. 沉淀模块：提炼训练数据
# ═══════════════════════════════════════

def save_training_data(evaluations: list[dict]) -> tuple[int, int]:
    """高分 → training_examples.json, 低分 → bad_cases.json"""
    # 加载现有训练数据
    current = []
    if os.path.exists(TRAINING_FILE):
        try:
            with open(TRAINING_FILE, encoding="utf-8") as f:
                current = json.load(f)
        except (json.JSONDecodeError, Exception):
            current = []

    # 加载现有 bad cases
    bad_cases = []
    if os.path.exists(BAD_CASES_FILE):
        try:
            with open(BAD_CASES_FILE, encoding="utf-8") as f:
                bad_cases = json.load(f)
        except (json.JSONDecodeError, Exception):
            bad_cases = []

    good_count = 0
    bad_count = 0

    for ev in evaluations:
        if ev["total"] >= SCORE_THRESHOLD_GOOD and ev.get("ai_reply"):
            entry = {
                "user": ev.get("user_input", ""),
                "reply": ev.get("ai_reply", ""),
            }
            # 避免重复
            if not any(e.get("user") == entry["user"] for e in current):
                current.append(entry)
                good_count += 1

        if ev["total"] <= SCORE_THRESHOLD_BAD:
            bad_cases.append({
                "case_id": ev.get("case_id", ""),
                "user_input": ev.get("user_input", ""),
                "ai_reply": ev.get("ai_reply", ""),
                "scores": ev.get("scores", {}),
                "total": ev.get("total", 0),
                "issue_flags": ev.get("issue_flags", []),
                "suggestion": ev.get("suggestion_for_improvement", ""),
                "timestamp": datetime.now().isoformat(),
            })
            bad_count += 1

    # 保存
    with open(TRAINING_FILE, "w", encoding="utf-8") as f:
        json.dump(current, f, ensure_ascii=False, indent=2)

    with open(BAD_CASES_FILE, "w", encoding="utf-8") as f:
        json.dump(bad_cases, f, ensure_ascii=False, indent=2)

    return good_count, bad_count


# ═══════════════════════════════════════
# 5. 报告模块
# ═══════════════════════════════════════

def generate_report(all_evaluations: list[dict], rounds: int) -> dict:
    """生成训练报告"""
    if not all_evaluations:
        return {"error": "无评估数据"}

    scores = [e["total"] for e in all_evaluations]
    verdicts = [e["verdict"] for e in all_evaluations]

    # 按场景统计
    by_scenario = {}
    for e in all_evaluations:
        s = e.get("scenario", "unknown")
        if s not in by_scenario:
            by_scenario[s] = {"count": 0, "scores": []}
        by_scenario[s]["count"] += 1
        by_scenario[s]["scores"].append(e["total"])

    # 按维度统计
    dim_scores = {"correctness": [], "completeness": [], "no_repetition": [], "tool_usage": [], "tone": []}
    for e in all_evaluations:
        for dim in dim_scores:
            val = e.get("scores", {}).get(dim, 0)
            if val:
                dim_scores[dim].append(val)

    report = {
        "timestamp": datetime.now().isoformat(),
        "total_rounds": rounds,
        "total_cases": len(all_evaluations),
        "average_score": round(sum(scores) / len(scores), 2) if scores else 0,
        "verdict_distribution": {
            "good": verdicts.count("good"),
            "pass": verdicts.count("pass"),
            "fail": verdicts.count("fail"),
            "error": verdicts.count("error"),
        },
        "by_scenario": {
            s: {
                "count": v["count"],
                "avg_score": round(sum(v["scores"]) / len(v["scores"]), 2) if v["scores"] else 0,
            }
            for s, v in sorted(by_scenario.items())
        },
        "by_dimension": {
            d: round(sum(v) / len(v), 2) if v else 0
            for d, v in dim_scores.items()
        },
        "top_issues": _collect_top_issues(all_evaluations),
    }

    with open(REPORT_FILE, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    return report


def _collect_top_issues(evaluations: list[dict]) -> list[dict]:
    """收集最高频问题"""
    issue_counter = {}
    for e in evaluations:
        for flag in e.get("issue_flags", []):
            issue_counter[flag] = issue_counter.get(flag, 0) + 1
    sorted_issues = sorted(issue_counter.items(), key=lambda x: -x[1])
    return [{"flag": k, "count": v} for k, v in sorted_issues[:10]]


# ═══════════════════════════════════════
# 6. 主控循环
# ═══════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Real-voice AI 训练测试评估系统")
    parser.add_argument("--rounds", type=int, default=DEFAULT_ROUNDS, help="迭代轮数")
    parser.add_argument("--cases", type=int, default=CASES_PER_ROUND, help="每轮测试用例数")
    args = parser.parse_args()

    print("=" * 60)
    print("  Real-voice AI 训练测试评估系统")
    print("=" * 60)
    print(f"  后端: {BACKEND_URL}")
    print(f"  LLM:  {DEEPSEEK_MODEL} ({DEEPSEEK_BASE_URL})")
    print(f"  轮数: {args.rounds}  |  每轮: {args.cases} 条")
    print(f"  收录阈值: ≥{SCORE_THRESHOLD_GOOD}  |  标记阈值: ≤{SCORE_THRESHOLD_BAD}")
    print("=" * 60)

    menu, menu_summary = init()

    all_evaluations = []
    existing_ids = set()
    total_good = 0
    total_bad = 0

    for r in range(1, args.rounds + 1):
        print(f"\n{'─' * 40}")
        print(f"📌 第 {r}/{args.rounds} 轮")
        print(f"{'─' * 40}")

        # Phase 1: 生成
        cases = generate_test_cases(menu_summary, args.cases, existing_ids)
        if not cases:
            print("  ⚠️ 本轮无新用例生成，跳过")
            continue

        # Phase 2: 测试
        results = run_test_batch(cases, f"train_r{r}")

        # Phase 3: 评估
        evaluations = evaluate_batch(results, menu_summary)
        all_evaluations.extend(evaluations)

        # Phase 4: 沉淀
        good, bad = save_training_data(evaluations)
        total_good += good
        total_bad += bad

        # 本轮小结
        round_scores = [e["total"] for e in evaluations]
        avg = sum(round_scores) / len(round_scores) if round_scores else 0
        print(f"\n  📈 本轮: 平均分 {avg:.2f} | 收录 {good} 条 | 标记 badcase {bad} 条")

    # 最终报告
    print(f"\n{'=' * 60}")
    print(f"  🏁 训练完成")
    print(f"{'=' * 60}")

    report = generate_report(all_evaluations, args.rounds)
    print(f"  总测试: {report['total_cases']} 条")
    print(f"  平均分: {report['average_score']}")
    print(f"  优秀 {report['verdict_distribution']['good']} | "
          f"通过 {report['verdict_distribution']['pass']} | "
          f"不通过 {report['verdict_distribution']['fail']} | "
          f"错误 {report['verdict_distribution']['error']}")
    print(f"  累计收录训练数据: {total_good} 条")
    print(f"  累计标记 badcase:  {total_bad} 条")
    print(f"\n  训练示例文件: {TRAINING_FILE}")
    print(f"  Badcase 文件:  {BAD_CASES_FILE}")
    print(f"  完整报告:      {REPORT_FILE}")

    if report.get("top_issues"):
        print(f"\n  ⚠️ Top 问题:")
        for issue in report["top_issues"][:5]:
            print(f"     {issue['flag']}: {issue['count']} 次")

    print(f"\n  按场景平均分:")
    for s, d in report.get("by_scenario", {}).items():
        bar = "█" * int(d["avg_score"])
        print(f"     {s}: {bar} {d['avg_score']} ({d['count']} 条)")


if __name__ == "__main__":
    main()

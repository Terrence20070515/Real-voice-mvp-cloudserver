# config.py — 训练测试评估系统配置

import os
from pathlib import Path
from dotenv import load_dotenv

# 从 ai_training/.env 加载环境变量（API Key 不硬编码，避免泄漏到 git）
load_dotenv(Path(__file__).parent / ".env")

# DeepSeek API — 双 Key：生成器和考官分开，各自独立
# 请在本目录的 .env 文件中配置（参考 .env.example）：
#   RV_GENERATOR_KEY=sk-xxx
#   RV_JUDGE_KEY=sk-xxx
GENERATOR_KEY = os.getenv("RV_GENERATOR_KEY", "")
JUDGE_KEY = os.getenv("RV_JUDGE_KEY", "")
DEEPSEEK_BASE_URL = os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com")
DEEPSEEK_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-chat")

# 后端地址（云托管公网）
BACKEND_URL = os.getenv(
    "BACKEND_URL",
    "https://real-voice-mvp-279101-7-1449503768.sh.run.tcloudbase.com",
)

# 数据文件
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BACKEND_DIR = os.path.join(os.path.dirname(BASE_DIR), "backend")
MENU_FILE = os.path.join(BACKEND_DIR, "menu.json")
TRAINING_FILE = os.path.join(BACKEND_DIR, "data", "training_examples.json")
BAD_CASES_FILE = os.path.join(BASE_DIR, "output", "bad_cases.json")
REPORT_FILE = os.path.join(BASE_DIR, "output", "training_report.json")

# 训练循环参数
DEFAULT_ROUNDS = 5            # 迭代轮数
CASES_PER_ROUND = 10          # 每轮生成 case 数
SCORE_THRESHOLD_GOOD = 4      # >= 此分数收录进训练示例
SCORE_THRESHOLD_BAD = 2       # <= 此分数标记为 badcase
MAX_RETRIES = 3               # 每个 case 最多重试次数

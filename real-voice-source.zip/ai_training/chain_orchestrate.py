#!/usr/bin/env python3
"""
Real-voice AI 训练测试评估系统 v2
=====================================
多轮会话链模式：生成完整对话链 → 同一 session 连续跑 → 评估整条链

与 v1 的关键区别：
  - v1: 每个 case 独立 session，单轮孤岛测试 ← 脱离实际
  - v2: 一条链 = 一个 session 连续多轮，场景自然交织 ← 真实用餐

用法:
  python3 chain_orchestrate.py                     # 默认 5 条链
  python3 chain_orchestrate.py --chains 10         # 10 条链
  python3 chain_orchestrate.py --chains 20 --max-turns 15  # 含长链
"""

import json
import os
import sys
import time
import argparse
from datetime import datetime

import requests
from openai import OpenAI

from config import (
    GENERATOR_KEY, JUDGE_KEY, DEEPSEEK_BASE_URL, DEEPSEEK_MODEL,
    BACKEND_URL, TRAINING_FILE, BAD_CASES_FILE, REPORT_FILE,
    SCORE_THRESHOLD_GOOD, SCORE_THRESHOLD_BAD, MAX_RETRIES,
)
from prompts import (
    CHAIN_GENERATOR_PROMPT, CHAIN_JUDGE_PROMPT,
    build_menu_summary, build_dish_list,
)


def init():
    os.makedirs(os.path.dirname(BAD_CASES_FILE), exist_ok=True)
    os.makedirs(os.path.dirname(REPORT_FILE), exist_ok=True)
    menu_path = os.path.join(os.path.dirname(__file__), "..", "backend", "menu.json")
    if not os.path.exists(menu_path):
        print(f"❌ 菜单未找到: {menu_path}")
        sys.exit(1)
    with open(menu_path, encoding="utf-8") as f:
        menu = json.load(f)
    return menu


# ═══════════════════════════════════════
# 1. 生成模块：产出多轮会话链
# ═══════════════════════════════════════

def generate_chains(menu: dict, total: int) -> list[dict]:
    """让生成器产出会话链。大批量时自动分批，避免 LLM 截断。"""
    client = OpenAI(api_key=GENERATOR_KEY, base_url=DEEPSEEK_BASE_URL)
    dish_list = build_dish_list(menu)

    all_chains = []
    batch_size = 4  # 每批最多生成 4 条，避免输出截断
    remaining = total

    for batch_idx in range(0, total, batch_size):
        batch_count = min(batch_size, remaining)
        prompt = CHAIN_GENERATOR_PROMPT.format(
            menu_dishes=dish_list,
            total_chains=batch_count,
        )
        print(f"  🎲 批次 {batch_idx//batch_size + 1}: 请求 {batch_count} 条...", end=" ", flush=True)
        try:
            resp = client.chat.completions.create(
                model=DEEPSEEK_MODEL,
                messages=[
                    {"role": "system", "content": "你是对话场景设计师。只输出 JSON。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.8,
                max_tokens=4096,
            )
            raw = resp.choices[0].message.content.strip()
            if raw.startswith("```"):
                raw = raw.split("\n", 1)[-1]
                if raw.endswith("```"):
                    raw = raw[:-3]
            data = json.loads(raw)
            chains = data.get("chains", data) if isinstance(data, dict) else data
            if isinstance(chains, list):
                all_chains.extend(chains)
                print(f"✅ {len(chains)} 条")
            else:
                print(f"⚠️ 非数组返回")
        except Exception as e:
            print(f"❌ {e}")
        remaining -= batch_count

    # 分配 ID
    for i, c in enumerate(all_chains):
        c["chain_id"] = f"chain_{i+1:03d}"
        c["total_turns"] = len(c.get("turns", []))

    print(f"  总计: {len(all_chains)} 条链 ({sum(c['total_turns'] for c in all_chains)} 轮)")
    return all_chains


# ═══════════════════════════════════════
# 2. 测试模块：按链顺序跑会话
# ═══════════════════════════════════════

def run_chain(chain: dict) -> dict:
    """对一条会话链的每一轮依次调用后端，同一 session_id"""
    turns = chain.get("turns", [])
    session_id = f"chain_test_{chain['chain_id']}_{int(time.time())}"
    transcript = []
    all_pass = True

    for t in turns:
        user_input = t["user_input"]
        turn_num = t["turn"]

        for attempt in range(MAX_RETRIES):
            try:
                resp = requests.post(
                    f"{BACKEND_URL}/api/chat",
                    json={"session_id": session_id, "message": user_input},
                    timeout=60,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    transcript.append({
                        "turn": turn_num,
                        "user": user_input,
                        "ai": data.get("reply", ""),
                        "expected": t.get("expected_behaviors", []),
                        "context_required": t.get("context_required", {}),
                        "status": "ok",
                    })
                    break
                else:
                    if attempt == MAX_RETRIES - 1:
                        transcript.append({
                            "turn": turn_num, "user": user_input, "ai": f"HTTP {resp.status_code}",
                            "status": "failed", "expected": t.get("expected_behaviors", []),
                        })
                        all_pass = False
            except Exception as e:
                if attempt == MAX_RETRIES - 1:
                    transcript.append({
                        "turn": turn_num, "user": user_input, "ai": str(e)[:100],
                        "status": "failed", "expected": t.get("expected_behaviors", []),
                    })
                    all_pass = False
            time.sleep(1)

        # 显示进度
        bar = "✅" if transcript[-1]["status"] == "ok" else "❌"
        print(f"    {bar} 第{turn_num}轮: {user_input[:35]}...")

    # 清除后端 session
    try:
        requests.post(f"{BACKEND_URL}/api/session/clear?session_id={session_id}", timeout=5)
    except:
        pass

    return {
        "chain_id": chain["chain_id"],
        "type": chain.get("type", ""),
        "title": chain.get("title", ""),
        "session_id": session_id,
        "total_turns": len(turns),
        "all_pass": all_pass,
        "transcript": transcript,
        "cross_turn_checks": chain.get("cross_turn_checks", []),
    }


def run_all_chains(chains: list[dict]) -> list[dict]:
    """批量跑所有链"""
    results = []
    for i, chain in enumerate(chains):
        turns = len(chain.get("turns", []))
        print(f"  🔗 [{i+1}/{len(chains)}] {chain['chain_id']} | {chain.get('type','')} | {turns}轮")
        result = run_chain(chain)
        results.append(result)
        time.sleep(1)
    return results


# ═══════════════════════════════════════
# 3. 评估模块：评估整条链
# ═══════════════════════════════════════

def evaluate_chain(result: dict, menu_summary: str) -> dict:
    """让考官评估一整条会话链"""
    client = OpenAI(api_key=JUDGE_KEY, base_url=DEEPSEEK_BASE_URL)

    if not result.get("all_pass"):
        return {
            "chain_id": result["chain_id"],
            "total_score": 0,
            "verdict": "error",
            "summary": "链中存在 HTTP 错误，无法评估",
        }

    # 构建对话记录文本
    transcript_lines = []
    for t in result["transcript"]:
        transcript_lines.append(f"第{t['turn']}轮:")
        transcript_lines.append(f"  顾客: {t['user']}")
        transcript_lines.append(f"  AI: {t['ai']}")
        transcript_lines.append("")

    # 跨轮检查项
    checks_text = "\n".join(f"- {c}" for c in result.get("cross_turn_checks", []))

    prompt = CHAIN_JUDGE_PROMPT.format(
        menu_summary=menu_summary,
        chain_id=result["chain_id"],
        cross_turn_checks=checks_text,
        conversation_transcript="\n".join(transcript_lines),
    )

    print(f"    📊 评估整条链...", end=" ", flush=True)
    try:
        resp = client.chat.completions.create(
            model=DEEPSEEK_MODEL,
            messages=[
                {"role": "system", "content": "你是严格的多轮对话质检员。只输出 JSON。"},
                {"role": "user", "content": prompt}
            ],
            temperature=0.1,
            max_tokens=2048,
        )
        raw = resp.choices[0].message.content.strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[-1]
            if raw.endswith("```"):
                raw = raw[:-3]
        ev = json.loads(raw)
        ev["chain_id"] = result["chain_id"]
        score = ev.get("total_score", 0)
        verdict = ev.get("verdict", "error")
        emoji = {"good": "🌟", "pass": "👍", "fail": "👎"}.get(verdict, "💀")
        print(f"{emoji} {verdict} ({score:.1f}/5)")
        return ev
    except Exception as e:
        print(f"💀 评估失败: {e}")
        return {
            "chain_id": result["chain_id"],
            "total_score": 0,
            "verdict": "error",
            "summary": f"评估异常: {e}",
        }


def evaluate_all(results: list[dict], menu_summary: str) -> list[dict]:
    evaluations = []
    for i, r in enumerate(results):
        print(f"  📋 [{i+1}/{len(results)}] {r['chain_id']} | {r.get('type','')} | {r['total_turns']}轮")
        ev = evaluate_chain(r, menu_summary)
        ev["_chain_type"] = r.get("type", "")
        ev["_turns"] = r["total_turns"]
        ev["_transcript"] = r.get("transcript", [])
        evaluations.append(ev)
    return evaluations


# ═══════════════════════════════════════
# 4. 沉淀模块：高分链 → 训练数据
# ═══════════════════════════════════════

def save_training_from_chains(evaluations: list[dict]) -> tuple[int, int]:
    """从高分链中提取每轮对话作为训练示例"""
    current = []
    if os.path.exists(TRAINING_FILE):
        try:
            with open(TRAINING_FILE, encoding="utf-8") as f:
                current = json.load(f)
        except:
            current = []

    bad = []
    if os.path.exists(BAD_CASES_FILE):
        try:
            with open(BAD_CASES_FILE, encoding="utf-8") as f:
                bad = json.load(f)
        except:
            bad = []

    good_count = 0
    bad_count = 0

    for ev in evaluations:
        transcript = ev.get("_transcript", [])
        chain_id = ev.get("chain_id", "")

        if ev.get("total_score", 0) >= SCORE_THRESHOLD_GOOD:
            for t in transcript:
                if t["status"] == "ok" and t.get("ai"):
                    entry = {"user": t["user"], "reply": t["ai"]}
                    if not any(e.get("user") == entry["user"] for e in current):
                        current.append(entry)
                        good_count += 1

        if ev.get("total_score", 0) <= SCORE_THRESHOLD_BAD:
            bad.append({
                "chain_id": chain_id,
                "type": ev.get("_chain_type", ""),
                "score": ev.get("total_score", 0),
                "verdict": ev.get("verdict", ""),
                "summary": ev.get("summary", ""),
                "memory_issues": ev.get("memory_issues", []),
                "weakest_turn": ev.get("weakest_turn"),
                "timestamp": datetime.now().isoformat(),
            })
            bad_count += 1

    with open(TRAINING_FILE, "w", encoding="utf-8") as f:
        json.dump(current, f, ensure_ascii=False, indent=2)
    with open(BAD_CASES_FILE, "w", encoding="utf-8") as f:
        json.dump(bad, f, ensure_ascii=False, indent=2)

    return good_count, bad_count


# ═══════════════════════════════════════
# 5. 报告
# ═══════════════════════════════════════

def generate_report(evaluations: list[dict]) -> dict:
    scores = [e.get("total_score", 0) for e in evaluations]
    verdicts = [e.get("verdict", "?") for e in evaluations]

    # 按链类型
    by_type = {}
    for e in evaluations:
        t = e.get("_chain_type", "unknown")
        if t not in by_type:
            by_type[t] = {"count": 0, "scores": [], "turns": []}
        by_type[t]["count"] += 1
        by_type[t]["scores"].append(e.get("total_score", 0))
        by_type[t]["turns"].append(e.get("_turns", 0))

    # 收集记忆问题
    memory_issues = []
    for e in evaluations:
        for issue in e.get("memory_issues", []):
            memory_issues.append(issue)

    report = {
        "timestamp": datetime.now().isoformat(),
        "total_chains": len(evaluations),
        "total_turns": sum(e.get("_turns", 0) for e in evaluations),
        "average_score": round(sum(scores) / len(scores), 2) if scores else 0,
        "verdict_distribution": {
            "good": verdicts.count("good"),
            "pass": verdicts.count("pass"),
            "fail": verdicts.count("fail"),
            "error": verdicts.count("error"),
        },
        "by_chain_type": {
            t: {
                "count": v["count"],
                "avg_score": round(sum(v["scores"]) / len(v["scores"]), 2) if v["scores"] else 0,
                "avg_turns": round(sum(v["turns"]) / len(v["turns"]), 1) if v["turns"] else 0,
            }
            for t, v in sorted(by_type.items())
        },
        "memory_issues_top10": _top(memory_issues, 10),
    }

    with open(REPORT_FILE, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

    return report


def _top(items: list, n: int) -> list[dict]:
    counter = {}
    for item in items:
        counter[item] = counter.get(item, 0) + 1
    return [{"issue": k, "count": v} for k, v in sorted(counter.items(), key=lambda x: -x[1])[:n]]


# ═══════════════════════════════════════
# 6. 主控
# ═══════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Real-voice v2 多轮会话链训练系统")
    parser.add_argument("--chains", type=int, default=8, help="会话链数量")
    parser.add_argument("--max-turns", type=int, default=12, help="单链最大轮数")
    args = parser.parse_args()

    print("=" * 60)
    print("  Real-voice v2 多轮会话链训练系统")
    print("=" * 60)
    print(f"  后端: {BACKEND_URL}")
    print(f"  生成器 Key: {GENERATOR_KEY[:12]}...  |  考官 Key: {JUDGE_KEY[:12]}...")
    print(f"  链数: {args.chains}  |  单链最大: {args.max_turns} 轮")
    print("=" * 60)

    menu = init()
    menu_summary = build_menu_summary(menu)

    # Step 1: 生成会话链
    print(f"\n📐 阶段一：生成会话链")
    chains = generate_chains(menu, args.chains)
    if not chains:
        print("❌ 无链生成，退出")
        return

    # Step 2: 逐链运行
    print(f"\n🧪 阶段二：运行会话链")
    results = run_all_chains(chains)

    # Step 3: 评估
    print(f"\n📊 阶段三：评估会话链")
    evaluations = evaluate_all(results, menu_summary)

    # Step 4: 沉淀
    print(f"\n💾 阶段四：沉淀训练数据")
    good, bad = save_training_from_chains(evaluations)
    print(f"  收录 {good} 条训练示例 | 标记 {bad} 条 bad chain")

    # 报告
    print(f"\n{'=' * 60}")
    print(f"  🏁 训练完成")
    print(f"{'=' * 60}")
    report = generate_report(evaluations)
    print(f"  链数: {report['total_chains']}  |  总轮数: {report['total_turns']}")
    print(f"  平均分: {report['average_score']}")
    print(f"  优秀 {report['verdict_distribution']['good']} | "
          f"通过 {report['verdict_distribution']['pass']} | "
          f"不通过 {report['verdict_distribution']['fail']}")

    print(f"\n  按链类型:")
    for t, d in report.get("by_chain_type", {}).items():
        bar = "█" * int(d["avg_score"])
        print(f"    {t}: {bar} {d['avg_score']} ({d['count']}条, 均{d['avg_turns']}轮)")

    if report.get("memory_issues_top10"):
        print(f"\n  🧠 跨轮记忆问题:")
        for item in report["memory_issues_top10"][:5]:
            print(f"    · {item['issue']} ({item['count']}次)")

    print(f"\n  训练示例: {TRAINING_FILE}")
    print(f"  报告:     {REPORT_FILE}")


if __name__ == "__main__":
    main()

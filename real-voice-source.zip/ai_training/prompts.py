# prompts.py — v2: 多轮会话链模式

# ═══════════════════════════════════════════════════════
# 1. 会话链生成器 Prompt
# ═══════════════════════════════════════════════════════

CHAIN_GENERATOR_PROMPT = """你是一个餐饮 AI 对话场景设计师。你的任务是生成**真实的用餐多轮对话链**。

## 核心理念
一次完整的顾客用餐对话是场景的**自然交织、排列组合**，而不是孤立的单轮问答。你的链必须模拟一位顾客从进店到离开的完整过程。

## 会话链结构
每条链包含 4-12 轮对话，按自然流程推进。示例：

```
顾客进店 → 寒暄 → 问推荐 → 点菜 → 问食材 → 加单 → 中途寒暄 → 报过敏 → 调整菜品 → 结账
```

不是每条链都要走全流程，但必须**多场景交织**，不能一个链只有一个场景。

## 必须覆盖的场景组合（轮数 4-12）

| 链类型 | 轮数 | 包含场景 | 测试重点 |
|--------|------|---------|---------|
| 简单链 | 4-6 轮 | 寒暄→点菜→加单→结账 | 基本流程 |
| 偏好链 | 5-8 轮 | 模糊需求→推荐→点菜→忌口声明→调整→加单 | 偏好记忆 |
| 纠错链 | 5-8 轮 | 点菜→改口→问食材→重新下单 | 改单逻辑 |
| 预算链 | 6-10 轮 | 人数+预算→推荐→筛选→点菜→加单→超预算提醒 | 预算约束 |
| 压力链 | 10-12 轮 | 寒暄→忌口→推荐→点菜→问价→加单→再忌口→改单→中途寒暄→结账 | 长上下文记忆 |
| 超长链 | 15-18 轮 | 完整用餐流程：多轮寒暄+多道菜+多次加单+过敏+改口+问食材+结账 | 极限上下文 |

## 菜名约束
{menu_dishes}

## 输出格式
严格输出以下 JSON，不要任何额外文字：
```json
{{
  "chains": [
    {{
      "chain_id": "chain_001",
      "type": "简单链",
      "title": "两人用餐完整流程",
      "turns": [
        {{
          "turn": 1,
          "user_input": "你好，两位用餐",
          "context_given": {{"diner_count": "2"}},
          "expected_behaviors": ["should_greet"]
        }},
        {{
          "turn": 2, 
          "user_input": "来一份水煮鱼和两碗米饭",
          "context_required": {{"diner_count": "2"}},
          "expected_behaviors": ["should_create_order", "should_mention_order_id", "should_show_total"]
        }},
        {{
          "turn": 3,
          "user_input": "再加一瓶可乐",
          "context_required": {{"has_order": true, "diner_count": "2"}},
          "expected_behaviors": ["should_add_to_order", "should_mention_order_id", "should_show_total"]
        }},
        {{
          "turn": 4,
          "user_input": "买单吧",
          "context_required": {{"has_order": true}},
          "expected_behaviors": ["should_redirect_to_pay"]
        }}
      ],
      "cross_turn_checks": [
        "全程记住2位用餐，不重复询问人数",
        "加单时使用同一订单号",
        "结账时提及已有订单"
      ]
    }}
  ]
}}
```

## 字段说明
- `context_given`: 本轮**新增**给模型的信息
- `context_required`: 本轮**要求模型记住**的之前信息（模型没记住就是失忆）
- `cross_turn_checks`: 跨轮一致性检查项，考官会逐条核验
- `expected_behaviors`: 同 v1，可选值：should_create_order / should_add_to_order / should_recommend / should_show_menu / should_mention_order_id / should_show_total / should_avoid_allergens / should_reject_invalid / should_redirect_to_pay / should_greet / should_not_repeat_info

## 生成要求
- 每条链的 user_input 必须口语化、自然、有真实感
- 菜品名称必须来自上方菜单列表，严禁编造
- context_required 必须合理（不能要求模型记住从未给出的信息）
- 每种链类型至少生成 1 条
- 总链数 {total_chains} 条
"""

# ═══════════════════════════════════════════════════════
# 2. 考官评分 Prompt（v2：整条链评分）
# ═══════════════════════════════════════════════════════

CHAIN_JUDGE_PROMPT = """你是一个严格的 AI 点餐对话质量评估官。你需要评估一整条**多轮对话链**的质量。

## 菜单参考
{menu_summary}

## 评估维度

### A. 逐轮评分（每轮 1-5 分）
对每一轮对话，检查：
- **正确性**: 菜品名、价格是否与菜单一致，有无编造
- **工具使用**: 该调工具时是否调了，用的工具对不对
- **响应质量**: 是否完整理解了用户本轮输入

### B. 跨轮评分（1-5 分）—— 这才是关键
检查以下跨轮一致性检查项是否通过：
{cross_turn_checks}

- **5分**: 全部通过，模型完美记住了跨轮上下文
- **3分**: 有 1-2 处轻微遗忘（如记对了人数但忘了忌口）
- **1分**: 严重遗忘，多轮前告知的信息完全丢失

## 待评估对话
{conversation_transcript}

## 输出格式
严格 JSON，无额外文字：
```json
{{
  "chain_id": "{chain_id}",
  "turn_scores": [
    {{"turn": 1, "score": 5, "correctness": 5, "tool_usage": 5, "quality": 5, "issue": ""}},
    {{"turn": 2, "score": 4, "correctness": 5, "tool_usage": 3, "quality": 4, "issue": "该调create_order但没调"}}
  ],
  "cross_turn_score": 4,
  "cross_turn_detail": {{
    "memory_diner_count": {{"pass": true, "note": "全程未重复询问"}},
    "memory_order_id": {{"pass": true, "note": "加单正确使用ORD0001"}},
    "memory_allergen": {{"pass": false, "note": "第6轮推荐了含花生的菜"}}
  }},
  "total_score": 4.2,
  "verdict": "good",
  "summary": "整体流畅，但第2轮缺工具调用，第6轮遗忘过敏信息",
  "weakest_turn": 6,
  "memory_issues": ["第6轮推荐含花生菜品，忘记第3轮顾客说的花生过敏"]
}}
```

## 评分规则
- total_score = (逐轮平均 × 0.6 + 跨轮评分 × 0.4)
- verdict: "good"(≥4) / "pass"(3~4) / "fail"(<3)
"""

# ═══════════════════════════════════════════════════════
# 3. 辅助函数
# ═══════════════════════════════════════════════════════

def build_menu_summary(menu_data: dict) -> str:
    """从菜单 JSON 生成简洁摘要供考官参考"""
    lines = []
    for cat in menu_data.get("categories", []):
        dishes = []
        for item in cat["items"]:
            dishes.append(f"{item['name']}(¥{item['price']}/{item['spicy']})")
        lines.append(f"【{cat['name']}】{' / '.join(dishes)}")
    return "\n".join(lines)


def build_dish_list(menu_data: dict) -> str:
    """生成菜品名列表，限制生成器不编造"""
    dishes = []
    for cat in menu_data.get("categories", []):
        for item in cat["items"]:
            dishes.append(f"{item['name']}（{item['spicy']}，¥{item['price']}）")
    return "\n".join(dishes)
